package models;

public enum OrderStatus {
    PLACED, APPROVED, DELIVERED
}
