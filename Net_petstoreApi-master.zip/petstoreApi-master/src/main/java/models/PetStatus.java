package models;

public enum PetStatus {
    AVAILABLE, PENDING, SOLD
}
